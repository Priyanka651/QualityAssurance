import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
//import org.testing.Assert;
//import org.testing.annotations.Test;
import org.junit.*;
import java.util.HashMap;

public class RestAssuredAPIVideoGameTest {

    @Test
    public void test_getAllVideoGames() {
        // Specify the base URL to the RESTful web service
        RestAssured.baseURI = "http://localhost:8080/app/videogames";

        // Get the RequestSpecification of the request to be sent to the server
        RequestSpecification httpRequest = RestAssured.given();

        // Use .get() method instead of method.GET
        Response response = httpRequest.get("");

        // Response.asString method will directly return the content of the body as String.
        System.out.println("Response of response.asString() print is =>  " + response.asString());

        // Get response getBody and Print
        String responseBody = response.getBody().asString();
        System.out.println("Response of getBody().asString is ==> " + responseBody);

        // Print the status and message body of the response received from the server
        System.out.println("Status response.getStatusLine() is ===> " + response.getStatusLine());
        System.out.println("Response of response.prettyPrint() is ====>" + response.prettyPrint());

        // Get Status code and print
        int statusCode = response.getStatusCode();
        System.out.println("Status code is " + statusCode);
        Assert.assertEquals(200, statusCode); // Assert that status code is 200

        // Get Status line and print
        String statusLine = response.getStatusLine();
        System.out.println("Status line is " + statusLine);

        // Assert that the status line contains HTTP version and status code
        Assert.assertTrue(statusLine.contains("HTTP/1.1"));
        Assert.assertTrue(statusLine.contains("200"));
    }

    @Test
    public void test_addNewVideoGame() {
        HashMap <String, Object> data = new HashMap <> ();
        data.put("id", "2100");
        data.put("name", " Priyanka - 20179"); // Your name - your student id
        data.put("releaseDate", "2023-10-01T11:54:39.518Z");
        data.put("reviewScore", "89");
        data.put("category", "indian");
        data.put("rating", "star");

        Response res =
                given()
                        .contentType("application/json")
                        .body(data)
                        .when()
                        .post("http://localhost:8080/app/videogames")
                        .then()
                        .statusCode(200)
                        .log().body()
                        .extract().response();
        String jsonString = res.asString();
        Assert.assertEquals(jsonString.contains("Record Added Successfully"), true);
        //Assert.assertEquals(jsonString.contains("Record Added Successfully"), true);
    }


    @Test
    public void test_getVideoGame() {
        given()
                .when()
                .get("http://localhost:8080/app/videogames/2100")
                .then()
                .statusCode(200)
                .log().body()
                .body("videoGame.id", equalTo ("2100"))
                .body("videoGame.name", equalTo ("Priyanka- 20179"));
    }

    @Test
    public void test_updatedVideoGame() {
        HashMap <String, Object> data = new HashMap <> ();
        data.put("id", "2100");
        data.put("name", "20179 - Priyanka"); // update to your student id - your first name/last name
        data.put("releaseDate", "2023-10-01T11:54:39.518Z");
        data.put("reviewScore", "50");
        data.put("category", "india");
        data.put("rating", "india");

        given()
                .contentType("application/json")
                .body(data)
                .when()
                .put("http://localhost:8080/app/videogames/2100")

                .then()
                .statusCode(200)
                .log().body()
                .body("videoGame.id", equalTo("2100"))
                .body("videoGame.name", equalTo("20179 - Priyanka"));
    }

    @Test
    public void test_DeleteVideoGame() {
        Response res =
                given()
                        .when()
                        .delete("http://localhost:8080/app/videogames/2100")
                        .then()
                        .statusCode(200)
                        .log().body()
                        .extract().response();
        String jsonString = res.asString();
        //Assert.assertEquals(jsonString.contains("Record Deleted Successfully"), true);
        Assert.assertTrue(jsonString.contains("Record Deleted Successfully"));
    }


}
